import time

import psutil as util



def get_data() -> None:
    boot_time = util.boot_time()
    cpu_count = util.cpu_count()
    cpu_usage = util.cpu_percent(interval=0.1, percpu=True)

    export = {
        'boot_time': boot_time,
        'core_count': cpu_count,
        'cpu_usage': cpu_usage,
    }

    print(export)


def main() -> None:
    while True:
        get_data()
        time.sleep(1)


if __name__ == '__main__':
    main()
